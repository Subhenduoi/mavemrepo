/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filescanner;

import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 *
 * @author 502320204
 */
public class ToHashCode {
 
    private String name;
 
    // standard getters/setters/constructors
         
     public int hashCode() {
        return Math.abs(new HashCodeBuilder(17, 37).
        append(name).
        toHashCode());
    }
         
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        if (this.getClass() != o.getClass()) return false;
        ToHashCode user = (ToHashCode) o;
        return (name.equals(user.name) 
          );
    }
     
    // getters and setters here

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }    
}