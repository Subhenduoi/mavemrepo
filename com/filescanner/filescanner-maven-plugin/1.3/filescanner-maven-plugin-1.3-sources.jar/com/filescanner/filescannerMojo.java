/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filescanner;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.apache.commons.io.filefilter.RegexFileFilter;

/**
 *
 * @author 502320204
 */
@Mojo(name = "fileScanner", defaultPhase = LifecyclePhase.GENERATE_SOURCES)
public class filescannerMojo extends AbstractMojo {

    @Parameter(defaultValue = "${project}", required = true, readonly = true)
    private MavenProject project;

    @Parameter(defaultValue = "1.0.1", required = true, readonly = true)
    private String version;

    @Parameter(defaultValue = "<hashcode>", required = true, readonly = true)
    private String toBeReplaceText;

    @Parameter(required = true, readonly = true)
    private List<String> fileRenameSets;
    
    @Parameter(required = true, readonly = true)
    private List<String> fileReplaceContentSets;

    @Parameter(defaultValue = "\\w*.min.[0-9]{5,}.txt", required = true, readonly = true)
    private String parterToDelete;

    @Override
    public void execute() throws MojoExecutionException, MojoFailureException {
        try {
            System.out.println("*********************************************************");
            System.out.println("************* MVP JAVA MOJO FILE Copy Replace PLUGIN *****************");
            System.out.println("*********************************************************");

            ToHashCode toHashCode = new ToHashCode();
            String hasCode = version + "-" + LocalDateTime.now().toString();
            toHashCode.setName(hasCode);
            hasCode = Integer.toString(toHashCode.hashCode());
            System.out.println(version + "-" + LocalDateTime.now().toString() + "->" + hasCode);
            //for (Map<String, String> fileset : fileRenameSets) { 
            for (String fileset : fileRenameSets) { 
                String fileExt=fileset.substring(fileset.lastIndexOf("."));
                String filePath=fileset.substring(0,fileset.lastIndexOf("."));
                String fileDestPath=filePath+".mv."+hasCode+".min"+fileExt;
                //File destination = new File(fileset.get("destinationFile").replaceAll(toBeReplaceText, hasCode));
                File destination = new File(fileDestPath);
                System.out.println(destination.getParentFile().getAbsoluteFile());
                filesDelete(destination.getParentFile().getAbsolutePath());
                renameFile(fileset,fileDestPath);
            }
            for (String fileset : fileReplaceContentSets) {
                fileReplaceContent(fileset, hasCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Renaming files  failed", e);
        }
    }

    private void renameFile(String fileSrc, String fileDest) {
        try {
            File source = new File(fileSrc);
            File destination = new File(fileDest);
            System.out.println("Renaming File: from " + source.getAbsolutePath() + " to " + destination.getPath());
            Files.copy(source.toPath(), destination.toPath());
        } catch (IOException e) {
            //Simple exception handling, replace with what's necessary for your use case!
            e.printStackTrace();
            throw new RuntimeException("Renaming files  failed", e);
        }
    }
    private void filesDelete(String diretroyPath) {
        File directory = new File(diretroyPath);
        //String pattern = "\\w*.min.[0-9]{5,}.txt";        
        FileFilter filter = new RegexFileFilter(parterToDelete);
        File[] files = directory.listFiles(filter);
        System.out.println(directory.getAbsolutePath());
        System.out.println(parterToDelete);
        System.out.println(files == null);
        System.out.println("Deleting " + files.length + " file(s) with parten : " + parterToDelete + " from " + directory.getAbsolutePath());
        for (File file : files) {
            System.out.print("              Deleting file: " + file.getPath() + ", Deleted: ");
            System.out.println(file.delete());
        }
    }

    private void fileReplaceContent(String fileset, String toReplace) {
        try {
            System.out.println("Replacing file content of "+ fileset);
            File tempFile = new File(fileset);
            String content = FileUtils.readFileToString(tempFile, "UTF-8");            
            content = findAndReplaceAll("mv\\.[0-9]*\\.min", "mv." + toReplace + ".min", content);            
            if(tempFile.exists())
                tempFile.delete();
            FileUtils.writeStringToFile(tempFile, content, "UTF-8");
        } catch (IOException e) {
            //Simple exception handling, replace with what's necessary for your use case!     
            e.printStackTrace();
            throw new RuntimeException("Generating file failed", e);
        }
    }
    private static String findAndReplaceAll( String patterns, String replaceWith,String inputString) {
        Pattern pattern = Pattern.compile(patterns);
        Matcher matcher = pattern.matcher(inputString);
        return matcher.replaceAll(replaceWith);
    }
}